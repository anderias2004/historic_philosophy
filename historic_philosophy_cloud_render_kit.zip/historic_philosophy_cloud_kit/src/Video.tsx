import React from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';

type Props = {title: string; hook: string; handle: string};

export const HistoryReel: React.FC<Props> = ({title, hook, handle}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const fade = interpolate(frame, [0, 24, durationInFrames - 24, durationInFrames], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const rise = interpolate(frame, [0, 35], [70, 0], {extrapolateRight: 'clamp'});
  const pulse = 1 + Math.sin(frame / 24) * 0.012;

  return (
    <AbsoluteFill style={{backgroundColor: '#08090c', color: '#f5f0e6', fontFamily: 'Arial, sans-serif', opacity: fade, overflow: 'hidden'}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 35%, #3b2b16 0%, #12100d 36%, #08090c 72%)'}} />
      <div style={{position: 'absolute', inset: 42, border: '2px solid rgba(201,164,92,.55)', borderRadius: 18}} />
      <div style={{position: 'absolute', top: 110, left: 70, right: 70, textAlign: 'center', color: '#c9a45c', fontSize: 27, letterSpacing: 7}}>
        HISTORY • PHILOSOPHY
      </div>
      <div style={{position: 'absolute', top: '30%', left: 90, right: 90, textAlign: 'center', transform: `translateY(${rise}px) scale(${pulse})`}}>
        <div style={{fontSize: 92, fontWeight: 800, lineHeight: 1.25, direction: 'rtl', textShadow: '0 8px 35px #000'}}>{title}</div>
        <div style={{height: 4, width: 190, margin: '45px auto', background: '#c9a45c'}} />
        <div style={{fontSize: 47, lineHeight: 1.7, direction: 'rtl', color: '#e8dcc4'}}>{hook}</div>
      </div>
      <div style={{position: 'absolute', bottom: 150, left: 0, right: 0, textAlign: 'center', color: '#c9a45c', fontSize: 32, letterSpacing: 2}}>{handle}</div>
    </AbsoluteFill>
  );
};