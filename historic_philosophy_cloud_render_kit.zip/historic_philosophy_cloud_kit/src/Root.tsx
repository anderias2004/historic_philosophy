import React from 'react';
import {Composition} from 'remotion';
import {HistoryReel} from './Video';

export const Root: React.FC = () => (
  <Composition
    id="HistoryReel"
    component={HistoryReel}
    durationInFrames={900}
    fps={30}
    width={1080}
    height={1920}
    defaultProps={{
      title: 'ژولیوس سزار',
      hook: 'مردی که جمهوری روم را به زانو درآورد',
      handle: '@historic_philosophy',
    }}
  />
);